//
//  ViewController.m
//  Atomicity
//
//  Created by zijiansun on 13/03/2018.
//  Copyright © 2018 zijiansun. All rights reserved.
//

#import "ViewController.h"

typedef struct tagStruct {
    NSInteger a;
    NSInteger b;
    NSInteger c;
    NSInteger d;
} Struct;

typedef struct tagShortStruct {
    char a;
} ShortStruct;

@interface Test : NSObject

@property (nonatomic) NSInteger nonatomicInteger;
@property (atomic) NSInteger atomicInteger;

@property (nonatomic) Struct nonatomicStruct;
@property (atomic) Struct atomicStruct;

@property (nonatomic) ShortStruct nonatomicShortStruct;
@property (atomic) ShortStruct atomicShortStruct;

@property (nonatomic) long long nonatomicLongLong;
@property (atomic) long long atomicLongLong;

@property (nonatomic) float nonatomicFloat;
@property (atomic) float atomicFloat;

@property (nonatomic) double nonatomicDouble;
@property (atomic) double atomicDouble;

@property (nonatomic, strong) id nonatomicStrongObject;
@property (atomic, strong) id atomicStrongObject;

@property (nonatomic, unsafe_unretained) id nonatomicUnsafeUnretainedObject;
@property (atomic, unsafe_unretained) id atomicUnsafeUnretainedObject;

@property (nonatomic, weak) id nonatomicWeakObject;
@property (atomic, weak) id atomicWeakObject;

@property (nonatomic, copy) id nonatomicCopyObject;
@property (atomic, copy) id atomicCopyObject;

@property (nonatomic, copy) void(^nonatomicCopiedBlock)(void);
@property (atomic, copy) void(^atomicCopiedBlock)(void);

@property (nonatomic, strong) void(^nonatomicStrongBlock)(void);
@property (atomic, strong) void(^atomicStrongBlock)(void);

@property (nonatomic, retain) void(^nonatomicRetainedBlock)(void);
@property (atomic, retain) void(^atomicRetainedBlock)(void);

@property (nonatomic, weak) void(^nonatomicWeakBlock)(void);
@property (atomic, weak) void(^atomicWeakBlock)(void);

@property (nonatomic, unsafe_unretained) void(^nonatomicUnsafeUnretainedBlock)(void);
@property (atomic, unsafe_unretained) void(^atomicUnsafeUnretainedBlock)(void);

@end

@implementation Test

- (void)test {
    self.nonatomicInteger = self.nonatomicInteger;
    self.atomicInteger = self.atomicInteger;

    self.nonatomicStruct = self.nonatomicStruct;
    self.atomicStruct = self.atomicStruct;

    self.nonatomicShortStruct = self.nonatomicShortStruct;
    self.atomicShortStruct = self.atomicShortStruct;

    self.nonatomicLongLong = self.nonatomicLongLong;
    self.atomicLongLong = self.atomicLongLong;

    self.nonatomicFloat = self.nonatomicFloat;
    self.atomicFloat = self.atomicFloat;

    self.nonatomicDouble = self.nonatomicDouble;
    self.atomicDouble = self.atomicDouble;

    self.nonatomicStrongObject = self.nonatomicStrongObject;
    self.atomicStrongObject = self.atomicStrongObject;

    self.nonatomicUnsafeUnretainedObject = self.nonatomicUnsafeUnretainedObject;
    self.atomicUnsafeUnretainedObject = self.atomicUnsafeUnretainedObject;

    self.nonatomicWeakObject = self.nonatomicWeakObject;
    self.atomicWeakObject = self.atomicWeakObject;

    self.nonatomicCopyObject = self.nonatomicCopyObject;
    self.atomicCopyObject = self.atomicCopyObject;

    self.nonatomicStrongBlock = self.nonatomicStrongBlock;
    self.atomicStrongBlock = self.atomicStrongBlock;

    self.nonatomicCopiedBlock = self.nonatomicCopiedBlock;
    self.atomicCopiedBlock = self.atomicCopiedBlock;

    self.nonatomicRetainedBlock = self.nonatomicRetainedBlock;
    self.atomicRetainedBlock = self.atomicRetainedBlock;

    self.nonatomicWeakBlock = self.nonatomicWeakBlock;
    self.atomicWeakBlock = self.atomicWeakBlock;

    self.nonatomicUnsafeUnretainedBlock = self.nonatomicUnsafeUnretainedBlock;
    self.atomicUnsafeUnretainedBlock = self.atomicUnsafeUnretainedBlock;
}

@end

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    [super touchesBegan:touches withEvent:event];

    [[[Test alloc] init] test];
}


@end
