//
//  AppDelegate.h
//  Atomicity
//
//  Created by zijiansun on 13/03/2018.
//  Copyright © 2018 zijiansun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

